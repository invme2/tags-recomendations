# Cluster Taxonomy v3.2 — Setup Guide

Полный комплект для интеграции системы тегирования с твоим Shopify-пайплайном.

## 📦 Что в комплекте

| Файл | Назначение |
|------|-----------|
| `taxonomy.json` | База из **765 кластеров** (430 V3.1 approved + 335 V3.2 draft) + 27 personas + 14 intents + 9 demos |
| `enrich_taxonomy.py` | Авто-обогащение метадаты через Claude API |
| `Shopify_Pipeline_v9_with_taxonomy.ipynb` | Твой пайплайн с интеграцией taxonomy |
| `README.md` | Этот файл |

---

## ⚠️ ОБЯЗАТЕЛЬНО ПЕРЕД ЗАПУСКОМ

В исходном `.ipynb` у тебя были **рабочие ключи в открытом виде**: Anthropic, Shopify, DataForSEO. Я их сохранил в патченой версии (она копирует Cell 1 из оригинала). **Сделай прямо сейчас:**

1. Зайди в Anthropic Console → Settings → API Keys → отзови старый, создай новый
2. Shopify Admin → Settings → Apps and sales channels → пересоздай токен
3. DataForSEO → отзови старый пароль
4. В Cell 1 заменись на чтение из переменных среды или Colab Secrets:
   ```python
   from google.colab import userdata
   ANTHROPIC_API_KEY = userdata.get('ANTHROPIC_API_KEY')
   SHOPIFY_CLIENT_SECRET = userdata.get('SHOPIFY_CLIENT_SECRET')
   ```

---

## 🚀 Шаги запуска (по порядку)

### Шаг 1 — Залить taxonomy.json в Git

```bash
# В новом приватном репо (например, на GitHub)
git init my-taxonomy && cd my-taxonomy
cp /path/to/taxonomy.json .
git add taxonomy.json
git commit -m "Initial taxonomy v3.2"
git remote add origin git@github.com:YOUR-ORG/my-taxonomy.git
git push -u origin main
```

Затем получи **raw URL** файла:
- GitHub: `https://raw.githubusercontent.com/YOUR-ORG/my-taxonomy/main/taxonomy.json`
- GitLab: `https://gitlab.com/YOUR-ORG/my-taxonomy/-/raw/main/taxonomy.json`

> Если репо приватный, нужен **personal access token**: `https://USER:TOKEN@raw.githubusercontent.com/...`. Лучше всё-таки сделай публичный — таксономия не секретная.

### Шаг 2 — Обогатить кластеры (опционально, но рекомендую)

```bash
pip install anthropic sentence-transformers faiss-cpu
export ANTHROPIC_API_KEY="sk-ant-..."

# Сначала тест на 1 батче (10 кластеров) чтобы проверить промпт:
python enrich_taxonomy.py --max-batches 1 --output taxonomy.test.json

# Если ОК — гоним полный прогон (~$3-5, 30-60 минут):
python enrich_taxonomy.py --output taxonomy.enriched.json

# Если упало посередине — продолжаем с того же места:
python enrich_taxonomy.py --resume --output taxonomy.enriched.json
```

После этого **закоммить enriched версию** в Git и обновить URL в пайплайне (или просто перезаписать файл по тому же URL — главное чтобы это была последняя версия).

**Что добавит обогащение:**
- `title_ru` (русский заголовок)
- `description` (1 предложение по-английски)
- `personas` (1-3 из master-списка)
- `intents` (1-2)
- `demos.primary_gender` + `demos.ages`
- `synonyms` (TikTok-сленг и т.п.)
- `shopify_collection_hints`
- `related` (5 ближайших кластеров через FAISS — без API)

### Шаг 3 — Подключить пайплайн

В `Shopify_Pipeline_v9_with_taxonomy.ipynb` → **Cell 1 (CONFIG)** найди и измени:

```python
TAXONOMY_URL = "https://raw.githubusercontent.com/YOUR-ORG/my-taxonomy/main/taxonomy.json"
TAXONOMY_REFRESH = False         # True = всегда тянуть свежую с URL
TAXONOMY_APPROVED_ONLY = False   # True = только V3.1 (без черновиков V3.2)
TAGS_PER_PRODUCT_MIN = 4
TAGS_PER_PRODUCT_MAX = 9
TAXONOMY_SHORTLIST_K = 40        # сколько кластеров в shortlist для каждого товара
```

### Шаг 4 — Прогнать пайплайн

Запускай ячейки последовательно:
- Cell 1 (Config) → загружает таксономию из URL впервые
- Cells 2-5 (как обычно)
- **Cell 5.5 (NEW) — Taxonomy Loader** → строит FAISS индекс
- Cell 6 (Product Loop) → теперь Stage 2 работает с shortlist + валидацией

В логах увидишь:
```
Taxonomy v3.2: 765 clusters, 27 personas, 14 intents
Active clusters: 765 (status: ['approved', 'draft'])
FAISS index: 765 vectors
```

И на каждом товаре после Stage 2:
```
Tags: 7 valid
```

Если будет:
```
⚠ Dropped 2 hallucinated tags: ['cluster:invented', 'persona:wrong']
```
— значит Claude всё-таки что-то выдумал, но валидатор это поймал.

---

## 🧪 Что изменилось в пайплайне

| Где | Что | Зачем |
|-----|-----|------|
| Cell 1 | Добавлены `TAXONOMY_*` константы | конфиг |
| **Cell 5.5 (NEW)** | Загрузчик + FAISS + helper-функции | новая инфраструктура |
| Cell 5 (CSS) | `WRITER_SYSTEM_PROMPT` теперь требует строгий формат тегов | контроль качества |
| Cell 6 (Product Loop) | Перед Stage 2: вычисляется shortlist из ~40 кластеров → инжектится в промпт | релевантность + экономия токенов |
| Cell 6 (Product Loop) | После Stage 2: валидация против master-таксономии, выкидываются галлюцинации | гарантия чистоты данных |

**Стоимость:** +~$0.004 на товар. На 100 товарах = **+$0.40**.

---

## 🛠 Как редактировать таксономию

### Через Git (рекомендуется)

1. Клонируй репо локально
2. Открой `taxonomy.json` в любом редакторе с поддержкой больших JSON (VS Code, IntelliJ)
3. Найди кластер по `tag` (Cmd+F → `cluster:morning-routine`)
4. Поправь поля
5. Закоммить + запушить
6. В пайплайне выстави `TAXONOMY_REFRESH = True` ИЛИ удали `pipeline.db` — заберёт свежую

### Добавить новый кластер

```json
{
  "tag": "cluster:my-new-cluster",
  "section_id": "22",
  "section": "health-wellness",
  "section_title_en": "Health & wellness",
  "title_en": "My new cluster",
  "title_ru": "Мой новый кластер",
  "description": "What this cluster is for, in one sentence.",
  "embed_text": "my new cluster keywords for FAISS search English and Russian terms",
  "typical_products": ["product1", "product2", "product3"],
  "personas": ["persona:wellness-seeker"],
  "intents": ["intent:essentials"],
  "demos": {"primary_gender": "demo:unisex", "ages": ["demo:adult"]},
  "related": [],
  "synonyms": ["search term 1", "search term 2"],
  "shopify_collection_hints": ["wellness", "health"],
  "status": "draft",
  "priority": "medium",
  "source": "manual"
}
```

Минимальный набор для работы — `tag`, `embed_text`, `status`. Остальное — желательно.

### Промоушн draft → approved

После того как поработал с кластером и убедился что он осмысленный, поменяй `"status": "draft"` → `"status": "approved"`.

---

## 📊 Полезные SQL-запросы

После загрузки таксономии в `pipeline.db`:

```sql
-- Сколько товаров на каждый кластер?
SELECT tc.tag, tc.title_en, COUNT(*) as n_products
FROM taxonomy_clusters tc
JOIN products p ON p.product_tags LIKE '%' || tc.tag || '%'
GROUP BY tc.tag
ORDER BY n_products DESC
LIMIT 50;

-- Кластеры с <3 товарами (надо удалить или объединить):
SELECT tc.tag, COUNT(p.id) as n
FROM taxonomy_clusters tc
LEFT JOIN products p ON p.product_tags LIKE '%' || tc.tag || '%'
GROUP BY tc.tag
HAVING n < 3;

-- Распределение по persona:
SELECT
  json_each.value as persona,
  COUNT(DISTINCT p.id) as n_products
FROM products p, json_each(p.product_tags)
WHERE json_each.value LIKE 'persona:%'
GROUP BY persona
ORDER BY n_products DESC;
```

---

## 🆘 Если что-то пошло не так

| Симптом | Причина | Решение |
|---------|---------|--------|
| `Failed to fetch taxonomy` | Неправильный URL или приватный репо без токена | Проверь URL в браузере |
| `FAISS index: 0 vectors` | Все кластеры отфильтровались | Проверь `TAXONOMY_APPROVED_ONLY` |
| `Dropped X hallucinated tags` (часто) | Claude игнорирует таксономию | Снизь `TAXONOMY_SHORTLIST_K` до 25, проверь промпт |
| Все товары получают одинаковые теги | Слабые embed_text | Прогони `enrich_taxonomy.py` для лучших синонимов |
| Cell 5.5 падает на `import sentence_transformers` | Не установлен | `!pip install sentence-transformers faiss-cpu -q` |

---

## 📈 Следующие шаги (V3.3 ideas)

- **Auto-tagger CLI** — берёт CSV товаров → выдаёт CSV с тегами без полного пайплайна
- **Coverage dashboard** — какие кластеры пустые, перекошены ли demo
- **Taxonomy linter** — pre-commit hook для Git, проверяет схему и дубли
- **A/B testing** — две версии таксономии, мерим CTR в персонализации

---

**Версия:** 3.2 · 2026-05-05
